package com.springcloud.controller;

import com.springcloud.serverInterface.FeignConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeignController {

    @Autowired
    private FeignConsumer feignConsumer;

    @RequestMapping(value = "/feign")
    public String hello() {
        return  feignConsumer.writePort();
    }

}
