package com.springcloud.controller;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class RibbonController {

    @Autowired
    private RestTemplate restTemplate;

    /**
     * 开启熔断@HystrixCommand
     * 熔断处理方法fallbackMethod
     * @return
     */
    @RequestMapping(value = "/ribbon")
    @HystrixCommand(fallbackMethod = "fallback")
    public String hello() {
        return restTemplate.getForEntity("http://eureka-provider-dev/", String.class).getBody();
    }

    public String fallback(){
        return "ribbon + hystrix ,提供者服务挂了";
    }

}
