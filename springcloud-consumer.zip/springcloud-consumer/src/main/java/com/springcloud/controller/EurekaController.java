package com.springcloud.controller;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EurekaController {

    @Autowired
    private EurekaClient client;

    @RequestMapping("/")
    public String hello() {
        InstanceInfo instanceInfo = client.getNextServerFromEureka("eureka-provider-dev", false);
        return instanceInfo.getHomePageUrl();
    }

}
