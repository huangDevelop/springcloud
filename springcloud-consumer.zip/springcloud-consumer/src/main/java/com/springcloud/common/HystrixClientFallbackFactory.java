package com.springcloud.common;

import com.springcloud.serverInterface.FeignConsumer;
import feign.hystrix.FallbackFactory;
import org.springframework.stereotype.Component;

@Component
/**
 * 将类加载到容器@Component
 * feign熔断处理类,重写create方法
 */
public class HystrixClientFallbackFactory implements FallbackFactory {

    @Override
    public FeignConsumer create(Throwable throwable) {
        return () -> "feign + hystrix ,提供者服务挂了";
    }

}
