package com.springcloud.serverInterface;

import com.springcloud.common.HystrixClientFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 指定调用服务提供者(eureka-provider-dev)
 */
//@FeignClient("eureka-provider-dev")
@FeignClient(value ="eureka-provider-dev",fallbackFactory = HystrixClientFallbackFactory.class)
public interface FeignConsumer {
    /**
     * 访问服务提供者方法
     * @return
     */
    @RequestMapping("/")
    String writePort();

}
